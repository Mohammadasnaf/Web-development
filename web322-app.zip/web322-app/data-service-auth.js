const bcrypt = require('bcryptjs');
const mongoose = require("mongoose");
const Schema = mongoose.Schema;

var userSchema = new Schema({
    "userName": {
        type: String,
        unique: true
    },
    "password": String,
    "email": String,
    "loginHistory":
        [
            {
                "dateTime": Date,
                "userAgent": String
            }
        ]
});

let User; 

module.exports.initialize = function () {
    return new Promise(function (resolve, reject) {
        let db = mongoose.createConnection("mongodb://<dbuser>:<dbpassword>@ds117111.mlab.com:17111/web322_a6"); 
        db.on('error', (err) => {
            reject(err); 
        });
        db.once('open', () => {
            User = db.model("users", userSchema);
            resolve();
        });
    });
};

module.exports.registerUser = function (userData) {
    return new Promise((resolve, reject) => {

        bcrypt.genSalt(10, function (err, salt) { 
            bcrypt.hash(userData.password, salt, function (err, hash) {
                if (err) {
                    reject(`There was an error encrypting the password`);
                    return;
                }

                if (userData.password != userData.password2) {
                    reject(`Passwords do not match!`);
                    return;
                } else {
                    userData.password = hash;
                    let newUser = new User(userData);
                    newUser.save((err) => {
                        if (err) {
                            if (err.code == 11000) 
                            {
                                reject("User Name already taken");
                                return;
                            } else {
                                reject(`There was an error creating the user ${err}`);
                                return;
                            }
                        } else {
                            resolve();
                        }
                    })
                }
            });
        });
    });
}

module.exports.checkUser = function (userData) {
    return new Promise((resolve, reject) => {
        User.find({ userName: userData.userName }).exec().then((data) => {
        
            if (data.length == 0) {
                reject(`No user found with this username ${userData.userName}`);
                return;
            }

           
            bcrypt.compare(userData.password, data[0].password).then((res) => {

                if (res === false) {
                    reject(`Incorrect Password for user: ${userData.userName}`)
                    return;
                }
                else
                {
                    data[0].loginHistory.push({ dateTime: (new Date()).toString(), userAgent: userData.userAgent });
                    console.log("<<<<<<<<<<<<< Login history" + data[0].loginHistory);
                    User.update(
                        { userName: data[0].userName },
                        { $set: { loginHistory: data[0].loginHistory } },
                        { multi: false }
                    ).exec().then(() => {
                        resolve(data[0]);
                    }).catch((err) => {
                        reject(`There was an error veryfying the user : ${err}`);
                    });        
                }});
        }).catch((err) => {
            reject(`Unable to find user: ${userData.userName}`);
        });
    })
}