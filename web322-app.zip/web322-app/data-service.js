/********************************************************************************
*  WEB 322 – Assignment 04
*
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy. No part 
*  of this assignment has been copied manually or electronically from any other source 
*  (including 3rd party web sites) or distributed to other students.
* 
*  Name: Mohammadasnaf Shaikh   Student ID: 153451174   Date:28 sept 2018
*
*  Online (Heroku) Link: https://obscure-lake-53200.herokuapp.com/
*
********************************************************************************/ 
const Sequelize = require('sequelize');

var sequelize = new Sequelize('d3jucaror3m9o7', 'tdykjtfppjjjul', '94c8df13badf4cdf68cc90bf924cf84cb2800b7297c9c31417898bde83a8b08b', {
 host: 'ec2-54-163-230-178.compute-1.amazonaws.com',
 dialect: 'postgres',
 port: 5432,
 dialectOptions: {
 ssl: true
 }
});
var Employee = sequelize.define('Employee', {
    employeeNum:{
        type: Sequelize.INTEGER,
        primaryKey: true, 
        autoIncrement: true 
    },
    firstname:Sequelize.STRING,
    lastname:Sequelize.STRING,
    email:Sequelize.STRING,
    SSN:Sequelize.STRING,
    addressStreet:Sequelize.STRING,
    addressCity:Sequelize.STRING,
    addressState:Sequelize.STRING,
    addressPostal:Sequelize.STRING,
    maritalStatus:Sequelize.STRING,
    isManager:Sequelize.BOOLEAN,
    employeeManagerNum:Sequelize.INTEGER,
    status:Sequelize.STRING,
    hireDate:Sequelize.STRING 
});


var Department = sequelize.define('Department', {
    departmentId:{
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    departmentName: Sequelize.STRING
    
});
Department.hasMany(Employee, {foreignKey: 'department'});
   

module.exports.initialize = function () {
    return new Promise(function (resolve, reject) {
        sequelize.sync().then(()=> {
            resolve("succesfully sync!");
        }).catch(()=>{
            reject("unable to sync the database!!!!!");
        })  
    });    
}
       

module.exports.getAllEmployees = function(){
    return new Promise(function (resolve, reject) {
        Employee.findAll({
        where:{

        }
        }).then((data)=>{
            resolve(data);
        }).catch((err)=>{
            reject(`failed data not found ${err}`);
        })
    });
}

module.exports.addEmployee = function (employeeData) {
    return new Promise(function (resolve, reject) {

        employeeData.isManager=(employeeData.isManagver)?true:false;   
        for (var i in employeeData){
            if (employeeData[i]==''){
                employeeData[i]=null;
            }
        }
        Employee.create(employeeData).then(()=>{
            resolve();
        }).catch((err)=>{
            reject("unable to create employee");
        });
    });
};

module.exports.getEmployeeByNum = function (empNum) {
    return new Promise(function (resolve, reject) {
        Employee.findOne({
            where :{employeeNum:empNum}
        }).then((data)=>{
            resolve(data);
        }).catch((err)=>{ reject(`failed employee not found by number ${err}`);})
   
    });
};

module.exports.getEmployeesByStatus = function (status) {
    return new Promise(function (resolve, reject) {
        Employee.findAll({
            where:{status:status}
        }).then((data)=>{
            resolve(data);
        }).catch((err)=>{
            reject(`failed employee not found by status ${err}`);
        })

    });
}


module.exports.getEmployeesByDepartment = function (department) {
    return new Promise(function (resolve, reject) {
      Employee.findAll({
          where :{department:department}
      }).then((data)=>{
          resolve(data);
      }).catch((err)=>{ reject(`failed employee not found by department ${err}`);})
    });
}

module.exports.getEmployeesByManager = function (manager) {
    return new Promise(function (resolve, reject) {
        Employee.findAll({
            where :{manager:manager}
        }).then((data)=>{
            resolve(data);
        }).catch((err)=>{ reject(`failed employee not found by manager ${err}`);})
    
    });
}

module.exports.getManagers = function () {
    return new Promise(function (resolve, reject) {
        reject();
    });
}

module.exports.getDepartments = function(){
    return new Promise(function (resolve, reject) {
        Department.findAll({
            where :{}
        }).then((data)=>{
            resolve(data);
        }).catch((err)=>{ reject(`failed department data not found ! ${err}`);})
      
    });
}
module.exports.updateEmployee=(employeeData)=>{
    return new Promise(function (resolve, reject) {
        employeeData.isManager=(employeeData.isManager)?true:false;
        Employee.update(employeeData,{where:{employeeNum:employeeData.employeeNum}
        }).then(()=>{
            resolve("Succefully updated!!");
        }).catch(()=>{
            reject(`failed to update employee ${err}`);
        })
    });
}
module.exports.addDepartment=function(departmentData){
    for(var i in departmentData){
        if (departmentData[i]==''){
            departmentData[i]=null;
        }
    }
    return new Promise((reslove,reject)=>{
        Department.create(departmentData).then(()=>{
            resolve(`Successfully created department`);
        }).catch(()=>{
            reject(`failed to create new department `);
        })
    })
}
module.exports.updateDepartment=function(departmentData){
    for (var i in departmentData){
        if(departmentData[i]=''){
            departmentData[i]=null;
        }

    }
    return new Promise((resolve,reject)=>{
        Department.update(departmentData,{
            where:{
                departmentId:departmentData.departmentId
            }
        }).then(()=>{
            resolve(`updated Successfully`);
        }).catch(()=>{
            reject(`failed to update department successfully`);
        })
    })
}
module.exports.getDepartmentById=function(id){
    return new Promise((resolve,reject)=>{
        Department.findOne({
            where:{
                departmentId:id
            }
        }).then((data)=>{
            resolve(data);
        }).catch((err)=>{
            reject(`no results returned ${err}`);
        })
    })
}
module.exports.deleteDepartmentById=function(id){
    return new Promise((resolve,reject)=>{
        Department.destory({
            where:{
                departmentId:id
            }
        }).then(()=>{
            resolve(`Successfully`);
        }).catch(()=>{
            reject(`no results returned`);
        })
    })
}
module.exports.deleteEmployeeByNum=function(empNum){
   
    return new Promise((resolve,reject)=>{
        Employee.destory({
            where:{
                employeeNum:empNum
            }
        }).then(()=>{
            resolve(`Successfully deleted`);
        }).catch(()=>{
            reject(`failed to delete`);
        })
    })
}
